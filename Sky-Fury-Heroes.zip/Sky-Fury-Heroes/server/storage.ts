import { db } from "./db";
import { leaderboards, type InsertLeaderboard, type Leaderboard } from "@shared/schema";
import { desc } from "drizzle-orm";

export interface IStorage {
  getLeaderboard(): Promise<Leaderboard[]>;
  createScore(score: InsertLeaderboard): Promise<Leaderboard>;
}

export class DatabaseStorage implements IStorage {
  async getLeaderboard(): Promise<Leaderboard[]> {
    return await db.select().from(leaderboards).orderBy(desc(leaderboards.score)).limit(10);
  }

  async createScore(score: InsertLeaderboard): Promise<Leaderboard> {
    const [newScore] = await db.insert(leaderboards).values(score).returning();
    return newScore;
  }
}

export const storage = new DatabaseStorage();
