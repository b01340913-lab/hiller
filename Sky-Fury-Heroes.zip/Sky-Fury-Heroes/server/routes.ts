import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get(api.leaderboard.list.path, async (req, res) => {
    try {
      const scores = await storage.getLeaderboard();
      res.json(scores);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  app.post(api.leaderboard.create.path, async (req, res) => {
    try {
      const input = api.leaderboard.create.input.parse(req.body);
      const score = await storage.createScore(input);
      res.status(201).json(score);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Failed to create score" });
    }
  });

  return httpServer;
}

// Simple seed function to populate some initial leaderboard scores
export async function seedDatabase() {
  try {
    const existing = await storage.getLeaderboard();
    if (existing.length === 0) {
      await storage.createScore({ playerName: "AcePilot", score: 5000 });
      await storage.createScore({ playerName: "Maverick", score: 3500 });
      await storage.createScore({ playerName: "RedBaron", score: 2000 });
    }
  } catch (error) {
    console.error("Failed to seed database:", error);
  }
}
