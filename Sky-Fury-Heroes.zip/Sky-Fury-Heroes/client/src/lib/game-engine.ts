// Pure TypeScript Game Engine for WW2 Dogfight

type Vector2D = { x: number; y: number };
type Team = 'ALLIED' | 'AXIS';

interface GameState {
  score: number;
  playerHealth: number;
  isGameOver: boolean;
  width: number;
  height: number;
  worldWidth: number;
  worldHeight: number;
}

export class GameEngine {
  private ctx: CanvasRenderingContext2D;
  private canvas: HTMLCanvasElement;
  private entities: Entity[] = [];
  private player!: Plane;
  private groundSoldiers: GroundSoldier[] = [];
  
  private lastTime: number = 0;
  private keys: Record<string, boolean> = {};
  
  public state: GameState;
  
  // Callbacks for React UI
  public onStateChange?: (state: GameState) => void;
  public onGameOver?: (score: number) => void;

  private animationFrameId: number = 0;
  private spawnTimer: number = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error("Could not get 2D context");
    this.ctx = ctx;
    
    this.state = {
      score: 0,
      playerHealth: 100,
      isGameOver: false,
      width: canvas.width,
      height: canvas.height,
      worldWidth: 4000,
      worldHeight: 4000
    };

    this.setupInputs();
    this.initGame();
  }

  private setupInputs() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
  }

  public cleanup() {
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    cancelAnimationFrame(this.animationFrameId);
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    this.keys[e.code] = true;
    // Prevent default scrolling for game keys
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
      e.preventDefault();
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  public initGame() {
    this.entities = [];
    this.groundSoldiers = [];
    this.state.score = 0;
    this.state.playerHealth = 100;
    this.state.isGameOver = false;
    this.notifyState();

    const cx = this.state.worldWidth / 2;
    const cy = this.state.worldHeight / 2;

    // Create Player
    this.player = new Plane(this, cx, cy, 'ALLIED', true);
    this.entities.push(this.player);

    // Create some NPC Teammates
    for (let i = 0; i < 5; i++) {
      this.entities.push(new Plane(this, cx + (Math.random() - 0.5) * 600, cy + (Math.random() - 0.5) * 600, 'ALLIED', false));
    }

    // Create Ground Soldiers
    for (let i = 0; i < 100; i++) {
      this.groundSoldiers.push(new GroundSoldier(
        Math.random() * this.state.worldWidth,
        Math.random() * this.state.worldHeight,
        Math.random() > 0.5 ? 'ALLIED' : 'AXIS'
      ));
    }

    this.lastTime = performance.now();
    this.loop(this.lastTime);
  }

  public resize(width: number, height: number) {
    this.canvas.width = width;
    this.canvas.height = height;
    this.state.width = width;
    this.state.height = height;
  }

  private loop = (timestamp: number) => {
    if (this.state.isGameOver) return;

    const dt = (timestamp - this.lastTime) / 1000; // Delta time in seconds
    this.lastTime = timestamp;

    this.update(dt);
    this.draw();

    this.animationFrameId = requestAnimationFrame(this.loop);
  };

  private update(dt: number) {
    // Process Player Input
    if (this.keys['ArrowLeft'] || this.keys['KeyA']) this.player.turn(-1, dt);
    if (this.keys['ArrowRight'] || this.keys['KeyD']) this.player.turn(1, dt);
    if (this.keys['ArrowUp'] || this.keys['KeyW']) this.player.throttle(1, dt);
    if (this.keys['ArrowDown'] || this.keys['KeyS']) this.player.throttle(-0.5, dt); // Brake
    if (this.keys['Space']) this.player.shoot();

    // Spawn Enemies
    this.spawnTimer += dt;
    if (this.spawnTimer > 1.5) { 
      this.spawnTimer = 0;
      if (this.getEntitiesByTeam('AXIS').length < 15) {
        this.spawnEnemy();
      }
    }

    // Update ground soldiers
    this.groundSoldiers.forEach(s => s.update(dt, this.state.worldWidth, this.state.worldHeight));

    // Update all entities
    for (let i = this.entities.length - 1; i >= 0; i--) {
      const entity = this.entities[i];
      entity.update(dt);

      // Check bounds
      if (entity instanceof Bullet || entity instanceof Particle) {
        if (entity.x < 0 || entity.x > this.state.worldWidth || entity.y < 0 || entity.y > this.state.worldHeight) {
          entity.markForDeletion = true;
        }
      } else if (entity instanceof Plane) {
        // Teleport back if out of world bounds
        if (entity.x < 0) entity.x = this.state.worldWidth;
        if (entity.x > this.state.worldWidth) entity.x = 0;
        if (entity.y < 0) entity.y = this.state.worldHeight;
        if (entity.y > this.state.worldHeight) entity.y = 0;
      }

      if (entity.markForDeletion) {
        this.entities.splice(i, 1);
      }
    }

    // Check collisions
    const bullets = this.entities.filter(e => e instanceof Bullet) as Bullet[];
    const planes = this.entities.filter(e => e instanceof Plane) as Plane[];

    for (const bullet of bullets) {
      for (const plane of planes) {
        if (bullet.team !== plane.team && !bullet.markForDeletion && !plane.markForDeletion) {
          const dx = bullet.x - plane.x;
          const dy = bullet.y - plane.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          if (dist < plane.radius) {
            bullet.markForDeletion = true;
            plane.takeDamage(15);
            this.spawnExplosion(bullet.x, bullet.y, 5, bullet.team === 'ALLIED' ? '#3b82f6' : '#ef4444');
          }
        }
      }
    }

    // Check Player Health
    if (this.player.health <= 0 && !this.state.isGameOver) {
      this.state.isGameOver = true;
      this.state.playerHealth = 0;
      this.notifyState();
      if (this.onGameOver) this.onGameOver(this.state.score);
    } else {
      // Sync health
      if (this.state.playerHealth !== this.player.health) {
        this.state.playerHealth = this.player.health;
        this.notifyState();
      }
    }
  }

  private draw() {
    const camX = this.player.x - this.state.width / 2;
    const camY = this.player.y - this.state.height / 2;

    this.ctx.save();
    this.ctx.translate(-camX, -camY);

    // Background - Battle Field
    this.ctx.fillStyle = '#14532d'; // Dark forest green
    this.ctx.fillRect(0, 0, this.state.worldWidth, this.state.worldHeight);

    // Grid / Dirt Patches
    this.ctx.strokeStyle = '#064e3b';
    this.ctx.lineWidth = 2;
    const gridSize = 200;
    for (let x = 0; x <= this.state.worldWidth; x += gridSize) {
      this.ctx.beginPath();
      this.ctx.moveTo(x, 0);
      this.ctx.lineTo(x, this.state.worldHeight);
      this.ctx.stroke();
    }
    for (let y = 0; y <= this.state.worldHeight; y += gridSize) {
      this.ctx.beginPath();
      this.ctx.moveTo(0, y);
      this.ctx.lineTo(this.state.worldWidth, y);
      this.ctx.stroke();
    }

    // Draw Ground Soldiers
    this.groundSoldiers.forEach(s => s.draw(this.ctx));

    // Draw World Border
    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    this.ctx.lineWidth = 10;
    this.ctx.strokeRect(0, 0, this.state.worldWidth, this.state.worldHeight);

    // Draw Entities
    this.entities.filter(e => !(e instanceof Plane)).forEach(e => e.draw(this.ctx));
    this.entities.filter(e => e instanceof Plane).forEach(e => e.draw(this.ctx));

    this.ctx.restore();

    // Minimap (Optional UI element)
    this.drawMinimap();
  }

  private drawMinimap() {
    const mapSize = 150;
    const padding = 20;
    this.ctx.save();
    this.ctx.translate(this.state.width - mapSize - padding, this.state.height - mapSize - padding);
    this.ctx.fillStyle = 'rgba(0,0,0,0.5)';
    this.ctx.fillRect(0, 0, mapSize, mapSize);
    this.ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    this.ctx.strokeRect(0, 0, mapSize, mapSize);

    this.entities.forEach(e => {
      if (e instanceof Plane) {
        this.ctx.fillStyle = e.isPlayer ? '#22c55e' : (e.team === 'ALLIED' ? '#3b82f6' : '#ef4444');
        const px = (e.x / this.state.worldWidth) * mapSize;
        const py = (e.y / this.state.worldHeight) * mapSize;
        this.ctx.beginPath();
        this.ctx.arc(px, py, e.isPlayer ? 3 : 2, 0, Math.PI * 2);
        this.ctx.fill();
      }
    });
    this.ctx.restore();
  }

  private spawnEnemy() {
    const dist = 800;
    const angle = Math.random() * Math.PI * 2;
    const ex = this.player.x + Math.cos(angle) * dist;
    const ey = this.player.y + Math.sin(angle) * dist;

    this.entities.push(new Plane(this, ex, ey, 'AXIS', false));
  }

  public addEntity(entity: Entity) {
    this.entities.push(entity);
  }

  public addScore(points: number) {
    this.state.score += points;
    this.notifyState();
  }

  public getEntitiesByTeam(team: Team): Plane[] {
    return this.entities.filter(e => e instanceof Plane && e.team === team) as Plane[];
  }

  public spawnExplosion(x: number, y: number, count: number, color: string) {
    for (let i = 0; i < count; i++) {
      this.entities.push(new Particle(this, x, y, color));
    }
  }

  private notifyState() {
    if (this.onStateChange) {
      this.onStateChange({ ...this.state });
    }
  }
}

class GroundSoldier {
  private angle: number = Math.random() * Math.PI * 2;
  private speed: number = 20 + Math.random() * 20;
  private shootTimer: number = Math.random() * 2;

  constructor(public x: number, public y: number, public team: Team) {}

  update(dt: number, worldWidth: number, worldHeight: number) {
    this.x += Math.cos(this.angle) * this.speed * dt;
    this.y += Math.sin(this.angle) * this.speed * dt;

    if (Math.random() < 0.01) this.angle += (Math.random() - 0.5) * 2;
    
    if (this.x < 0) this.x = worldWidth;
    if (this.x > worldWidth) this.x = 0;
    if (this.y < 0) this.y = worldHeight;
    if (this.y > worldHeight) this.y = 0;

    this.shootTimer -= dt;
    if (this.shootTimer <= 0) {
      this.shootTimer = 2 + Math.random() * 5;
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = this.team === 'ALLIED' ? '#1e40af' : '#991b1b';
    ctx.beginPath();
    ctx.arc(this.x, this.y, 2, 0, Math.PI * 2);
    ctx.fill();
  }
}

abstract class Entity {
  public markForDeletion: boolean = false;
  constructor(
    protected engine: GameEngine,
    public x: number,
    public y: number,
    public vx: number = 0,
    public vy: number = 0
  ) {}
  abstract update(dt: number): void;
  abstract draw(ctx: CanvasRenderingContext2D): void;
  
  public isOutOfBounds(width: number, height: number, margin: number = 100): boolean {
    return (this.x < -margin || this.x > width + margin || this.y < -margin || this.y > height + margin);
  }

  public wrapBounds(width: number, height: number) {
    if (this.x < 0) this.x = width;
    if (this.x > width) this.x = 0;
    if (this.y < 0) this.y = height;
    if (this.y > height) this.y = 0;
  }
}

class Plane extends Entity {
  public angle: number = 0;
  public speed: number = 200;
  public maxSpeed: number = 400;
  public health: number = 100;
  public radius: number = 15;
  private shootCooldown: number = 0;

  constructor(
    engine: GameEngine,
    x: number, y: number,
    public team: Team,
    public isPlayer: boolean
  ) {
    super(engine, x, y);
    if (this.isPlayer) this.angle = -Math.PI / 2;
    else this.angle = Math.random() * Math.PI * 2;
  }

  update(dt: number) {
    if (this.health <= 0) {
      this.markForDeletion = true;
      this.engine.spawnExplosion(this.x, this.y, 20, '#f97316');
      if (this.team === 'AXIS' && !this.isPlayer) {
        this.engine.addScore(100);
      }
      return;
    }

    if (!this.isPlayer) {
      this.runAI(dt);
    }

    this.vx = Math.cos(this.angle) * this.speed;
    this.vy = Math.sin(this.angle) * this.speed;
    this.x += this.vx * dt;
    this.y += this.vy * dt;

    if (this.shootCooldown > 0) {
      this.shootCooldown -= dt;
    }
  }

  runAI(dt: number) {
    const enemies = this.engine.getEntitiesByTeam(this.team === 'ALLIED' ? 'AXIS' : 'ALLIED');
    if (enemies.length === 0) return;

    let closest = enemies[0];
    let minDist = Infinity;
    
    for (const enemy of enemies) {
      const d = Math.hypot(enemy.x - this.x, enemy.y - this.y);
      if (d < minDist) { minDist = d; closest = enemy; }
    }

    if (closest) {
      const targetAngle = Math.atan2(closest.y - this.y, closest.x - this.x);
      let diff = targetAngle - this.angle;
      while (diff < -Math.PI) diff += Math.PI * 2;
      while (diff > Math.PI) diff -= Math.PI * 2;

      const turnSpeed = 2.5;
      if (Math.abs(diff) > 0.1) {
        this.angle += Math.sign(diff) * Math.min(Math.abs(diff), turnSpeed * dt);
      }

      if (Math.abs(diff) < 0.3 && minDist < 600) {
        this.shoot();
      }
    }
  }

  turn(dir: number, dt: number) {
    const turnRate = 4.0;
    this.angle += dir * turnRate * dt;
  }

  throttle(amt: number, dt: number) {
    const accel = 200;
    this.speed += amt * accel * dt;
    this.speed = Math.max(100, Math.min(this.speed, this.maxSpeed));
  }

  shoot() {
    if (this.shootCooldown <= 0) {
      this.engine.addEntity(new Bullet(this.engine, this.x, this.y, this.angle, this.team));
      this.shootCooldown = 0.15;
    }
  }

  takeDamage(amount: number) {
    this.health -= amount;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.angle);

    const s = 1.3;

    if (this.isPlayer) {
      ctx.fillStyle = '#22c55e'; // Green for Player
    } else if (this.team === 'ALLIED') {
      ctx.fillStyle = '#3b82f6'; // Blue for Allies
    } else {
      ctx.fillStyle = '#ef4444'; // Red for Nazis
    }

    // Fuselage
    ctx.beginPath();
    ctx.moveTo(15*s, 0);
    ctx.lineTo(-10*s, 5*s);
    ctx.lineTo(-10*s, -5*s);
    ctx.fill();

    // Wings
    ctx.beginPath();
    ctx.moveTo(5*s, 0);
    ctx.lineTo(-5*s, 20*s);
    ctx.lineTo(-10*s, 20*s);
    ctx.lineTo(-3*s, 0);
    ctx.lineTo(-10*s, -20*s);
    ctx.lineTo(-5*s, -20*s);
    ctx.fill();

    // Symbols
    ctx.fillStyle = 'white';
    if (this.isPlayer || this.team === 'ALLIED') {
      ctx.beginPath();
      ctx.arc(0, 0, 3*s, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.strokeStyle = 'black';
      ctx.lineWidth = 1.5*s;
      ctx.beginPath();
      ctx.moveTo(-3*s, -3*s); ctx.lineTo(3*s, 3*s);
      ctx.moveTo(3*s, -3*s); ctx.lineTo(-3*s, 3*s);
      ctx.stroke();
    }

    if (this.health < 100) {
      ctx.rotate(-this.angle);
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillRect(-15, -25, 30, 4);
      ctx.fillStyle = this.health > 40 ? '#22c55e' : '#ef4444';
      ctx.fillRect(-15, -25, 30 * (Math.max(0, this.health) / 100), 4);
    }

    ctx.restore();
  }
}

class Bullet extends Entity {
  private speed: number = 800;
  constructor(engine: GameEngine, x: number, y: number, angle: number, public team: Team) {
    // Start slightly ahead of plane
    super(engine, x + Math.cos(angle)*15, y + Math.sin(angle)*15);
    this.vx = Math.cos(angle) * this.speed;
    this.vy = Math.sin(angle) * this.speed;
  }

  update(dt: number) {
    this.x += this.vx * dt;
    this.y += this.vy * dt;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.shadowBlur = 8;
    ctx.shadowColor = this.team === 'ALLIED' ? '#fbbf24' : '#ef4444'; // Amber / Red glow
    ctx.fillStyle = this.team === 'ALLIED' ? '#fde68a' : '#fca5a5';
    ctx.beginPath();
    ctx.arc(this.x, this.y, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

class Particle extends Entity {
  private life: number = 1.0;
  private maxLife: number = 1.0;
  constructor(engine: GameEngine, x: number, y: number, private color: string) {
    super(engine, x, y);
    const angle = Math.random() * Math.PI * 2;
    const speed = Math.random() * 100 + 50;
    this.vx = Math.cos(angle) * speed;
    this.vy = Math.sin(angle) * speed;
    this.life = Math.random() * 0.5 + 0.2;
    this.maxLife = this.life;
  }

  update(dt: number) {
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.life -= dt;
    if (this.life <= 0) this.markForDeletion = true;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.globalAlpha = Math.max(0, this.life / this.maxLife);
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}
