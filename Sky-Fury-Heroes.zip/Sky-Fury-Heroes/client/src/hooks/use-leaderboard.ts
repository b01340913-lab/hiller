import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type ScoreInput } from "@shared/routes";

export function useLeaderboard() {
  return useQuery({
    queryKey: [api.leaderboard.list.path],
    queryFn: async () => {
      const res = await fetch(api.leaderboard.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch leaderboard");
      const data = await res.json();
      return api.leaderboard.list.responses[200].parse(data);
    },
    // Poll every 10 seconds to keep leaderboard fresh while playing
    refetchInterval: 10000,
  });
}

export function useSubmitScore() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: ScoreInput) => {
      // Ensure we're sending exactly what the schema expects
      const payload = api.leaderboard.create.input.parse(data);
      
      const res = await fetch(api.leaderboard.create.path, {
        method: api.leaderboard.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const errorData = await res.json();
          throw new Error(errorData.message || "Invalid score submission");
        }
        throw new Error("Failed to submit score");
      }
      
      const responseData = await res.json();
      return api.leaderboard.create.responses[201].parse(responseData);
    },
    onSuccess: () => {
      // Invalidate the leaderboard query to fetch the updated rankings
      queryClient.invalidateQueries({ queryKey: [api.leaderboard.list.path] });
    },
  });
}
