import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Skull, Send, RefreshCw, AlertCircle } from "lucide-react";
import confetti from "canvas-confetti";
import { useSubmitScore } from "@/hooks/use-leaderboard";

// Assume we copy the insert schema logic here since we can't directly import from @shared/schema in UI cleanly without it existing
const scoreSchema = z.object({
  playerName: z.string().min(2, "Codename must be at least 2 characters").max(15, "Codename too long"),
  score: z.number()
});

type ScoreFormValues = z.infer<typeof scoreSchema>;

interface GameOverModalProps {
  score: number;
  isOpen: boolean;
  onRestart: () => void;
}

export default function GameOverModal({ score, isOpen, onRestart }: GameOverModalProps) {
  const { mutate: submitScore, isPending, error: submitError } = useSubmitScore();
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const form = useForm<ScoreFormValues>({
    resolver: zodResolver(scoreSchema),
    defaultValues: {
      playerName: "",
      score: score
    }
  });

  // Reset form when modal opens with new score
  useEffect(() => {
    if (isOpen) {
      form.setValue("score", score);
      setHasSubmitted(false);
      
      // Trigger confetti if score is decent
      if (score > 500) {
        setTimeout(() => {
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#D4AF37', '#ffffff', '#4A5D23']
          });
        }, 300);
      }
    }
  }, [isOpen, score, form]);

  const onSubmit = (data: ScoreFormValues) => {
    submitScore(data, {
      onSuccess: () => {
        setHasSubmitted(true);
      }
    });
  };

  const handlePlayAgain = () => {
    form.reset();
    setHasSubmitted(false);
    onRestart();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-background/80 backdrop-blur-sm"
        />

        {/* Modal Content */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-md bg-secondary border border-white/10 shadow-2xl rounded-2xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-destructive/10 p-8 border-b border-destructive/20 text-center">
            <div className="mx-auto w-16 h-16 bg-destructive/20 text-destructive rounded-full flex items-center justify-center mb-4 ring-4 ring-destructive/10">
              <Skull className="w-8 h-8" />
            </div>
            <h2 className="text-3xl font-display font-bold text-destructive">MIA</h2>
            <p className="text-muted-foreground mt-2">Your plane was shot down over enemy territory.</p>
          </div>

          <div className="p-8 space-y-6">
            <div className="text-center bg-black/30 p-4 rounded-xl border border-white/5">
              <p className="text-sm uppercase tracking-widest text-muted-foreground mb-1">Final Score</p>
              <p className="font-mono text-5xl font-black text-glow">{score.toLocaleString()}</p>
            </div>

            {!hasSubmitted ? (
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Enter Pilot Codename
                  </label>
                  <input 
                    {...form.register("playerName")}
                    className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/10 text-foreground font-mono focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-all uppercase placeholder:normal-case placeholder:text-muted-foreground"
                    placeholder="e.g. MAVERICK"
                    autoFocus
                    autoComplete="off"
                    maxLength={15}
                  />
                  {form.formState.errors.playerName && (
                    <p className="mt-2 text-sm text-destructive flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      {form.formState.errors.playerName.message}
                    </p>
                  )}
                  {submitError && (
                    <p className="mt-2 text-sm text-destructive flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      Transmission failed. Try again.
                    </p>
                  )}
                </div>

                <div className="pt-2 flex gap-3">
                  <button 
                    type="button" 
                    onClick={handlePlayAgain}
                    className="flex-1 py-3 px-4 rounded-xl font-medium border border-white/10 hover:bg-white/5 text-foreground transition-all flex items-center justify-center gap-2"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Skip
                  </button>
                  <button 
                    type="submit" 
                    disabled={isPending}
                    className="flex-[2] py-3 px-4 rounded-xl font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isPending ? (
                      <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Transmit Score
                      </>
                    )}
                  </button>
                </div>
              </form>
            ) : (
              <div className="text-center py-4 space-y-6">
                <div className="text-emerald-400 font-medium">
                  Transmission successful. Your valor is recorded.
                </div>
                <button 
                  onClick={handlePlayAgain}
                  className="w-full py-4 px-4 rounded-xl font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2"
                >
                  <RefreshCw className="w-5 h-5" />
                  Scramble New Fighter
                </button>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
