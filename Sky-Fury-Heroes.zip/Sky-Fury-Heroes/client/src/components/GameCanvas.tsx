import { useEffect, useRef, useState, useCallback } from "react";
import { GameEngine } from "@/lib/game-engine";
import { Crosshair, Heart, Plane, Trophy } from "lucide-react";

interface GameCanvasProps {
  onGameOver: (score: number) => void;
}

export default function GameCanvas({ onGameOver }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const [score, setScore] = useState(0);
  const [health, setHealth] = useState(100);

  // Initialize Game
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const engine = new GameEngine(canvasRef.current);
    engineRef.current = engine;

    // Handle Resize
    const handleResize = () => {
      if (containerRef.current && engineRef.current) {
        const { clientWidth, clientHeight } = containerRef.current;
        engineRef.current.resize(clientWidth, clientHeight);
      }
    };

    // Initial size
    handleResize();
    window.addEventListener('resize', handleResize);

    // Setup Callbacks to sync state to UI
    engine.onStateChange = (state) => {
      setScore(state.score);
      setHealth(state.playerHealth);
    };

    engine.onGameOver = (finalScore) => {
      onGameOver(finalScore);
    };

    return () => {
      window.removeEventListener('resize', handleResize);
      engine.cleanup();
    };
  }, [onGameOver]);

  const restartGame = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.initGame();
    }
  }, []);

  return (
    <div className="relative w-full h-full overflow-hidden bg-slate-950 rounded-2xl border border-white/10 shadow-2xl shadow-black/50" ref={containerRef}>
      {/* The actual canvas */}
      <canvas 
        ref={canvasRef} 
        className="block touch-none"
        style={{ width: '100%', height: '100%' }}
      />

      {/* HUD Overlay */}
      <div className="absolute top-0 left-0 w-full p-6 flex justify-between items-start pointer-events-none z-10">
        
        {/* Left Side: Health */}
        <div className="flex flex-col gap-2">
          <div className="glass-panel px-4 py-3 rounded-xl flex items-center gap-3">
            <div className={`p-2 rounded-full ${health > 30 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-destructive/20 text-destructive animate-pulse'}`}>
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Integrity</p>
              <div className="w-32 h-2.5 bg-black/40 rounded-full mt-1 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-300 ${health > 30 ? 'bg-emerald-500' : 'bg-destructive'}`}
                  style={{ width: `${Math.max(0, health)}%` }}
                />
              </div>
            </div>
            <span className="font-mono text-xl font-bold w-12 text-right">{Math.ceil(health)}%</span>
          </div>
          
          <div className="glass-panel px-4 py-2 rounded-lg flex items-center gap-3 w-fit opacity-80">
            <Plane className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-mono uppercase tracking-tight">Allies in Area</span>
          </div>
        </div>

        {/* Right Side: Score */}
        <div className="glass-panel px-6 py-4 rounded-xl flex flex-col items-end">
          <div className="flex items-center gap-2 text-primary">
            <Trophy className="w-5 h-5" />
            <span className="text-sm font-medium uppercase tracking-widest">Combat Score</span>
          </div>
          <span className="font-mono text-5xl font-black tracking-tight text-glow-primary mt-1">
            {score.toString().padStart(6, '0')}
          </span>
        </div>
      </div>

      {/* Controls helper */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 glass-panel px-6 py-3 rounded-full flex gap-6 text-sm text-muted-foreground pointer-events-none">
        <span className="flex items-center gap-2"><kbd className="bg-black/50 px-2 py-0.5 rounded font-mono text-foreground border border-white/10">W A S D</kbd> Steer</span>
        <span className="flex items-center gap-2"><kbd className="bg-black/50 px-2 py-0.5 rounded font-mono text-foreground border border-white/10">SPACE</kbd> Fire</span>
      </div>

    </div>
  );
}
