import { useLeaderboard } from "@/hooks/use-leaderboard";
import { Trophy, Medal, Crown, Activity } from "lucide-react";
import { motion } from "framer-motion";

export default function LeaderboardSidebar() {
  const { data: scores, isLoading, isError } = useLeaderboard();

  return (
    <div className="h-full flex flex-col bg-secondary/40 backdrop-blur-xl border-l border-white/10">
      
      {/* Header */}
      <div className="p-6 border-b border-white/5 bg-black/20">
        <h2 className="flex items-center gap-3 text-2xl font-bold tracking-tight">
          <Trophy className="w-6 h-6 text-primary" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-white/60">
            Hall of Valor
          </span>
        </h2>
        <p className="text-sm text-muted-foreground mt-2 flex items-center gap-2">
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          Live WW2 combat rankings
        </p>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="h-16 rounded-xl bg-white/5 animate-pulse" />
            ))}
          </div>
        )}

        {isError && (
          <div className="p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm text-center">
            Failed to load communications. Check frequency.
          </div>
        )}

        {scores?.length === 0 && (
          <div className="text-center text-muted-foreground py-10 flex flex-col items-center gap-3">
            <Trophy className="w-10 h-10 opacity-20" />
            <p>No aces recorded yet.</p>
          </div>
        )}

        {scores?.map((entry, idx) => (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05, duration: 0.3 }}
            key={entry.id}
            className={`
              relative overflow-hidden group
              flex items-center gap-4 p-4 rounded-xl border transition-all duration-300
              ${idx === 0 ? 'bg-primary/10 border-primary/30 shadow-[0_0_15px_rgba(212,175,55,0.15)]' : 'bg-black/20 border-white/5 hover:bg-white/5'}
            `}
          >
            {/* Rank Icon/Number */}
            <div className={`
              w-10 h-10 shrink-0 rounded-full flex items-center justify-center font-bold font-mono text-lg
              ${idx === 0 ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/40' : 
                idx === 1 ? 'bg-slate-300 text-slate-800' :
                idx === 2 ? 'bg-amber-700 text-amber-100' : 'bg-white/5 text-muted-foreground'}
            `}>
              {idx === 0 ? <Crown className="w-5 h-5" /> : idx === 1 || idx === 2 ? <Medal className="w-5 h-5" /> : `#${idx + 1}`}
            </div>

            {/* Name */}
            <div className="flex-1 min-w-0">
              <div className={`font-semibold truncate ${idx === 0 ? 'text-primary' : 'text-foreground'}`}>
                {entry.playerName}
              </div>
              <div className="text-xs text-muted-foreground">
                Pilot
              </div>
            </div>

            {/* Score */}
            <div className="text-right shrink-0">
              <div className="font-mono font-bold text-lg text-glow">
                {entry.score.toLocaleString()}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
