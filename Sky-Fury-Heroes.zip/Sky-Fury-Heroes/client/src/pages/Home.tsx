import { useState, useCallback } from "react";
import GameCanvas from "@/components/GameCanvas";
import LeaderboardSidebar from "@/components/Leaderboard";
import GameOverModal from "@/components/GameOverModal";

export default function Home() {
  const [gameOverState, setGameOverState] = useState<{ isOver: boolean; score: number }>({
    isOver: false,
    score: 0
  });

  // We use a key to force complete remount of the GameCanvas when restarting
  const [gameKey, setGameKey] = useState(0);

  const handleGameOver = useCallback((finalScore: number) => {
    setGameOverState({ isOver: true, score: finalScore });
  }, []);

  const handleRestart = useCallback(() => {
    setGameOverState({ isOver: false, score: 0 });
    setGameKey(prev => prev + 1); // Remounts canvas component
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col lg:flex-row overflow-hidden">
      
      {/* Main Game Area */}
      <main className="flex-1 relative p-4 lg:p-6 h-[60vh] lg:h-screen flex flex-col">
        {/* Header (Mobile only) */}
        <div className="lg:hidden mb-4 flex items-center justify-between">
          <h1 className="font-display font-bold text-xl tracking-tight">DOGFIGHT <span className="text-primary">1944</span></h1>
        </div>

        {/* Game Container */}
        <div className="flex-1 relative rounded-2xl overflow-hidden shadow-2xl shadow-black/60 ring-1 ring-white/10">
          <GameCanvas key={gameKey} onGameOver={handleGameOver} />
        </div>
      </main>

      {/* Sidebar Area */}
      <aside className="w-full lg:w-[400px] h-[40vh] lg:h-screen shrink-0">
        <LeaderboardSidebar />
      </aside>

      {/* Modals */}
      <GameOverModal 
        isOpen={gameOverState.isOver} 
        score={gameOverState.score}
        onRestart={handleRestart}
      />
    </div>
  );
}
