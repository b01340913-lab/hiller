## Packages
framer-motion | Page transitions and high-quality UI animations
react-hook-form | Robust form state management for score submission
@hookform/resolvers | Zod validation integration for forms
canvas-confetti | Celebration effects for high scores
@types/canvas-confetti | TypeScript definitions for canvas-confetti

## Notes
- The WW2 Dogfight game runs entirely in the browser using HTML5 Canvas within a React component.
- The game engine uses `requestAnimationFrame` for the game loop and handles its own internal state to avoid React render cycle overhead for 60FPS entities.
- It communicates back to React (for UI updates like score and health) via callbacks.
- API interactions for the leaderboard assume the backend `GET /api/leaderboard` returns an array of scores, and `POST /api/leaderboard` accepts `{ playerName, score }`.
