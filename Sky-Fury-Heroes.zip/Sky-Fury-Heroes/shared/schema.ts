import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const leaderboards = pgTable("leaderboards", {
  id: serial("id").primaryKey(),
  playerName: text("player_name").notNull(),
  score: integer("score").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLeaderboardSchema = createInsertSchema(leaderboards).omit({ id: true, createdAt: true });

export type Leaderboard = typeof leaderboards.$inferSelect;
export type InsertLeaderboard = z.infer<typeof insertLeaderboardSchema>;

export type CreateScoreRequest = InsertLeaderboard;
export type ScoreResponse = Leaderboard;
export type LeaderboardListResponse = Leaderboard[];
